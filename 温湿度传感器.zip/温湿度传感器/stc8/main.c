#include <STC8.H>
#include "user.h"

void Delay1ms(unsigned int t)		//@11.0592MHz
{
	while(t--)
	{
	unsigned char i, j;

	_nop_();
	_nop_();
	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
}
}


void bspinit(void)
{
						SCL          =1;        //I2Cʱ����
				SDA          =1;        //I2C������
		beepoff;
		led0on;
		led1on;
		P_SW2 |= 0x04;
    UartInit();
		Uart4Init();
	  IE2 |= 0x10;
		OLED_Init();
		sht30_init(); //sht30��ʼ��
    ES = 1;
    EA = 1;
}


//extern SHT30_temperature;
void main(void)
{	
				char t;
				unsigned char value;
				unsigned char str[80];
				unsigned int cnt=0;
				bspinit();
				OLED_Clear(); 
				t=' ';
				OLED_ShowCHinese(0,0,0);
				OLED_ShowCHinese(18,0,1);
				OLED_ShowCHinese(36,0,2);
				OLED_ShowCHinese(54,0,3);
				OLED_ShowCHinese(72,0,4);
				OLED_ShowCHinese(90,0,5);
				OLED_ShowCHinese(108,0,6);
				Delay1ms(1000);
				wifi_protocol_init();
				Delay1ms(1000);
				mcu_reset_wifi();
				Delay1ms(1000);
				mcu_set_wifi_mode(SMART_CONFIG);
				Delay1ms(1000);
			while (1)
			{
				wifi_uart_service();
					//Delay1ms(1000);
//					
					Delay1ms(1);
					cnt++;
					if(cnt>=10000)
					{
						cnt=0;
				mcu_get_wifi_connect_status();
				sht30_data_process();
				sprintf(str,"tempture:%.1f\r\n",SHT30_temperature/10.0);
				UartSendStr(str);
				mcu_dp_value_update(DPID_TEMP_CURRENT,SHT30_temperature);     //VALUE�������ϱ�;
				Delay1ms(300);
				sprintf(str,"humidity:%.1f\r\n",SHT30_humidity/10.0);
				UartSendStr(str);
				Delay1ms(300);
			mcu_dp_value_update(DPID_HUMIDITY_VALUE,SHT30_humidity/10.0); //VALUE�������ϱ�;
				value=mcu_get_wifi_work_state();
				sprintf(str,"state:%x\r\n",value);
				UartSendStr(str);
				}
			}
} 