#ifndef __USER_H
#define __USER_H	
#include <stc8.H>
#include "wifi.h"
#include "uart1.h"
#include "uart4.h"
#include "stdio.h"
#include "intrins.h"
#include "oled.h"
#include "math.h"
#include "sht30.h"
#define led0on P50=0
#define led1on P51=0
#define led0off P50=1
#define led1off P51=1
#define beepon P26=1
#define beepoff P26=0

//==============================================================================
//��������
//==============================================================================
typedef struct {
	signed int temper;                                        //�¶�
  unsigned char humidity;                                         //ʪ��
	unsigned long run_time;                                        //�ۼ�����ʱ��
  unsigned char Power;
	unsigned int SAMPLING;
	
} TYPE_BUFFER_S;
extern TYPE_BUFFER_S FlashBuffer;
void Delay1ms(unsigned int t)	;	//@11.0592MHz

#endif  
	 