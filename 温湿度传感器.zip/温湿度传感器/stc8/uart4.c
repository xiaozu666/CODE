#include "stc8.h"
#include "intrins.h"
#include "uart4.h"
#include <wifi.h>
#define FOSC             11059200UL
#define BRT             (65536 - FOSC / 9600 / 4)


bit busy4;
char wptr4;
char rptr4;
char buffer4[16];

void Uart4Isr() interrupt 18 using 1
{
		unsigned char res;
    if (S4CON & 0x02)
    {
        S4CON &= ~0x02;
        busy4 = 0;
    }
    if (S4CON & 0x01)
    {
        S4CON &= ~0x01;
        res = S4BUF;
        wptr4 &= 0x0f;
    }
		res = S4BUF;
		uart_receive_input(res);
}

void Uart4Init()
{
    S4CON = 0x50;
    T4L = BRT;
    T4H = BRT >> 8;
    T4T3M = 0xa0;
  //  AUXR = 0x14|0x15;                                //������ʱ��
    wptr4 = 0x00;
    rptr4 = 0x00;
    busy4 = 0;
}

void Uart4Send(char dat)
{
    while (busy4);
    busy4 = 1;
    S4BUF = dat;
}

void Uart4SendStr(char *p)
{
    while (*p)
    {
        Uart4Send(*p++);
    }
}


